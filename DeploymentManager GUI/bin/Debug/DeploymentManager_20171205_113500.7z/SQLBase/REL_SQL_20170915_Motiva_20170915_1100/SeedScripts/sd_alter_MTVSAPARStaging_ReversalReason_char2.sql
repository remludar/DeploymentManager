alter table mtvsaparstaging alter column ReversalReason char(2)
