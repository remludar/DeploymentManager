
exec sp_addmessage 60010, 17, '%s'

