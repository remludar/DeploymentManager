delete from MTVTMSClassOfTradeXRef

insert into MTVTMSClassOfTradeXRef
(DistributionChannel, ClassOfTrade, TMSHostCode, CommercialFuelIndicator, BrandType, EffectiveFrom, EffectiveTo, LastUpdateUserID, LastUpdateDate, Status)
values ('14', '01', '02', 'N', 'S', '2016-01-01 00:00:00.000', '2049-12-31 00:00:00.000', 1429, '2016-05-31 10:20:34.763', 'A')

insert into MTVTMSClassOfTradeXRef
(DistributionChannel, ClassOfTrade, TMSHostCode, CommercialFuelIndicator, BrandType, EffectiveFrom, EffectiveTo, LastUpdateUserID, LastUpdateDate, Status)
values ('14', '02', '03', 'Y', 'U', '2016-01-01 00:00:00.000', '2049-12-31 00:00:00.000', 1429, '2016-05-31 10:20:34.763', 'A')

insert into MTVTMSClassOfTradeXRef
(DistributionChannel, ClassOfTrade, TMSHostCode, CommercialFuelIndicator, BrandType, EffectiveFrom, EffectiveTo, LastUpdateUserID, LastUpdateDate, Status)
values ('14', '03', '03', 'Y', 'U', '2016-01-01 00:00:00.000', '2049-12-31 00:00:00.000', 1429, '2016-05-31 10:20:34.763', 'A')

insert into MTVTMSClassOfTradeXRef
(DistributionChannel, ClassOfTrade, TMSHostCode, CommercialFuelIndicator, BrandType, EffectiveFrom, EffectiveTo, LastUpdateUserID, LastUpdateDate, Status)
values ('14', '05', '09', 'Y', 'U', '2016-01-01 00:00:00.000', '2049-12-31 00:00:00.000', 1429, '2016-05-31 10:20:34.763', 'A')

insert into MTVTMSClassOfTradeXRef
(DistributionChannel, ClassOfTrade, TMSHostCode, CommercialFuelIndicator, BrandType, EffectiveFrom, EffectiveTo, LastUpdateUserID, LastUpdateDate, Status)
values ('14', '06', '09', 'Y', 'U', '2016-01-01 00:00:00.000', '2049-12-31 00:00:00.000', 1429, '2016-05-31 10:20:34.763', 'A')

insert into MTVTMSClassOfTradeXRef
(DistributionChannel, ClassOfTrade, TMSHostCode, CommercialFuelIndicator, BrandType, EffectiveFrom, EffectiveTo, LastUpdateUserID, LastUpdateDate, Status)
values ('14', '00', '01', 'N', 'S', '2016-01-01 00:00:00.000', '2049-12-31 00:00:00.000', 1429, '2016-05-31 10:20:34.763', 'A')

insert into MTVTMSClassOfTradeXRef
(DistributionChannel, ClassOfTrade, TMSHostCode, CommercialFuelIndicator, BrandType, EffectiveFrom, EffectiveTo, LastUpdateUserID, LastUpdateDate, Status)
values ('03', '00', '05', 'N', 'S', '2016-01-01 00:00:00.000', '2049-12-31 00:00:00.000', 1429, '2016-05-31 10:20:34.763', 'A')

insert into MTVTMSClassOfTradeXRef
(DistributionChannel, ClassOfTrade, TMSHostCode, CommercialFuelIndicator, BrandType, EffectiveFrom, EffectiveTo, LastUpdateUserID, LastUpdateDate, Status)
values ('13', '00', '06', 'N', 'S', '2016-01-01 00:00:00.000', '2049-12-31 00:00:00.000', 1429, '2016-05-31 10:20:34.763', 'A')

insert into MTVTMSClassOfTradeXRef
(DistributionChannel, ClassOfTrade, TMSHostCode, CommercialFuelIndicator, BrandType, EffectiveFrom, EffectiveTo, LastUpdateUserID, LastUpdateDate, Status)
values ('00', '00', '04', 'N', 'S', '2016-01-01 00:00:00.000', '2049-12-31 00:00:00.000', 1429, '2016-05-31 10:20:34.763', 'A')

