exec SP_Set_Registry_Value 'Motiva\SAP\MonthsOfDataToKeep', '3'
exec SP_Set_Registry_Value 'Motiva\DataLake\MonthsOfDataToKeep', '3'