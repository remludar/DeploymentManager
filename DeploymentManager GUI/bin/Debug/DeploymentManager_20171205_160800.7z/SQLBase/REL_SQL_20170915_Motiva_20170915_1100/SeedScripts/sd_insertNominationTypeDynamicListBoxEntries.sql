delete 
--select *
from dynamiclistbox where DynLstBxQlfr = 'NominationType'

DECLARE	@i_id	INT
exec	sp_getkey 'dynamiclistbox', @i_id OUT
insert into dynamiclistbox (	DynLstBxID
				,DynLstBxQlfr
				,DynLstBxTyp
				,DynLstBxDesc
				,DynLstBxAbbv
				,DynLstBxOrdr
				,DynLstBxTblTyp
				,DynLstBxStts )
	Values (@i_id, 
		'NominationType', 
		'C',
		'Create',
		'Create',
		'10',
		'S',
		'A')

GO

DECLARE	@i_id	INT
exec	sp_getkey 'dynamiclistbox', @i_id OUT
insert into dynamiclistbox (	DynLstBxID
				,DynLstBxQlfr
				,DynLstBxTyp
				,DynLstBxDesc
				,DynLstBxAbbv
				,DynLstBxOrdr
				,DynLstBxTblTyp
				,DynLstBxStts )
	Values (@i_id, 
		'NominationType', 
		'M',
		'Change',
		'Change',
		'20',
		'S',
		'A')

GO

delete 
--select *
from dynamiclistbox where DynLstBxQlfr = 'T4NominationPipeLine'

DECLARE	@i_id	INT
exec	sp_getkey 'dynamiclistbox', @i_id OUT
insert into dynamiclistbox (	DynLstBxID
				,DynLstBxQlfr
				,DynLstBxTyp
				,DynLstBxDesc
				,DynLstBxAbbv
				,DynLstBxOrdr
				,DynLstBxTblTyp
				,DynLstBxStts )
	Values (@i_id, 
		'T4NominationPipeLine', 
		'1',
		'COLONIAL PIPELINE CO',
		'COLONIAL PIPELINE CO',
		'10',
		'S',   -- Need to verify
		'A')

GO

DECLARE	@i_id	INT
exec	sp_getkey 'dynamiclistbox', @i_id OUT
insert into dynamiclistbox (	DynLstBxID
				,DynLstBxQlfr
				,DynLstBxTyp
				,DynLstBxDesc
				,DynLstBxAbbv
				,DynLstBxOrdr
				,DynLstBxTblTyp
				,DynLstBxStts )
	Values (@i_id, 
		'T4NominationPipeLine', 
		'2',
		'BUCKEYE PIPE LINE CO',
		'BUCKEYE PIPE LINE CO',
		'20',
		'S',  -- Need to verify
		'A')

GO