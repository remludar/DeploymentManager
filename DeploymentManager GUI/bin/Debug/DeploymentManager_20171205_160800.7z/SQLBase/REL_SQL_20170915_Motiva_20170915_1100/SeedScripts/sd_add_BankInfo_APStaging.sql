alter table MTVSAPAPStaging add BankRoute varchar(50)
alter table MTVSAPAPStaging add BankAcct varchar(50)
