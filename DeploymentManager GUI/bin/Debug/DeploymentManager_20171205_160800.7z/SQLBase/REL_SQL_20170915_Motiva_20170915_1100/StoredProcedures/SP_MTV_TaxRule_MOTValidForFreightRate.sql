/*
*****************************************************************************************************
USE FIND AND REPLACE ON MTV_TaxRule_MOTValidForFreightRate WITH YOUR Stored Procedure name
*****************************************************************************************************
*/

/****** Object:  StoredProcedure [dbo].[MTV_TaxRule_MOTValidForFreightRate]    Script Date: DATECREATED ******/
PRINT 'Start Script=MTV_TaxRule_MOTValidForFreightRate.sql  Domain=MTV  Time=' + CONVERT(VARCHAR(50), GETDATE(), 109) + ' on ' + @@SERVERNAME+'.'+db_name()
GO

IF  OBJECT_ID(N'[dbo].[MTV_TaxRule_MOTValidForFreightRate]') IS NULL
      BEGIN
			EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[MTV_TaxRule_MOTValidForFreightRate] AS SELECT 1'
			PRINT '<<< CREATED StoredProcedure MTV_TaxRule_MOTValidForFreightRate >>>'
	  END
GO

SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS ON
GO

ALTER PROCEDURE [dbo].[MTV_TaxRule_MOTValidForFreightRate]
	(
	@ac_profile char (1)= 'N'
	)
AS

-- =============================================
-- Author:        rlb
-- Create date:	  09/25/2016
-- Description:   used by the tax rule if the carrier on the movement equals the taxing authority BA on the Tax record.
--					Originally written by Matt Perry
-- =============================================
-- Date         Modified By     Issue#  Modification
-- -----------  --------------  ------  ---------------------------------------------------------------------

-----------------------------------------------------------------------------

Set NoCount ON

Declare	@vc_sql varchar (8000),
		@i_RuleID int

Select	@i_RuleID = TxRleID
from	TaxRule
Where	[Description] = 'MOT valid for Freight Rate'

If @ac_profile = 'N'
Begin
	Delete	#Temp_TaxData
	From	#Temp_TaxData
			Inner Join TaxRuleSetRule (NoLock)	On	TaxRuleSetRule.TxRleStID = #Temp_TaxData.TxRleStID
												And	TaxRuleSetRule.TxRleID = @i_RuleID
			Inner Join Tax (NoLock)				On Tax.TxID = TaxRuleSetRule.TxID
	Where	Not Exists
			(
			Select	1
			--select *
			From	TransactionHeader (NoLock)
					Inner Join PlannedTransfer (NoLock)	On	TransactionHeader.XHdrPlnndTrnsfrID = PlannedTransfer.PlnndTrnsfrID
					AND	PlannedTransfer.MethodTransportation IN (select DynamicListBox.DynLstBxTyp 
																from	GeneralConfiguration (NoLock)
																INNER JOIN	DynamicListBox  (NoLock)
																ON	GeneralConfiguration.GnrlCnfgHdrID = DynamicListBox.DynLstBxID
																where	GeneralConfiguration.GnrlCnfgQlfr = 'IncludeTruckFreight'
																AND		GnrlCnfgMulti = 'Y'
																AND		GnrlCnfgTblNme = 'DynamicListBox'
																AND		GnrlCnfgHdrID <> 0
																)
			Where	TransactionHeader.XHdrID = #Temp_TaxData.SourceID	
			)
end 
Else
Begin
	select @vc_sql = 
	'
	Update  #Temp_TaxData
	Set 	DWExpression = """0"""
	From	#Temp_TaxData
			Inner Join TaxRuleSetRule (NoLock)	On	TaxRuleSetRule.TxRleStID = #Temp_TaxData.TxRleStID
												And	TaxRuleSetRule.TxRleID = ' + Convert(Varchar,@i_RuleID) +
'
			Inner Join Tax (NoLock)				On Tax.TxID = TaxRuleSetRule.TxID
	Where	Not Exists
			(
			Select	1
			From	TransactionHeader (NoLock)
					Inner Join PlannedTransfer (NoLock)	On	TransactionHeader.XHdrPlnndTrnsfrID = PlannedTransfer.PlnndTrnsfrID
					AND	PlannedTransfer.MethodTransportation IN (select DynamicListBox.DynLstBxTyp 
																from	GeneralConfiguration (NoLock)
																INNER JOIN	DynamicListBox  (NoLock)
																ON	GeneralConfiguration.GnrlCnfgHdrID = DynamicListBox.DynLstBxID
																where	GeneralConfiguration.GnrlCnfgQlfr = ''IncludeTruckFreight''
																AND		GnrlCnfgMulti = ''Y''
																AND		GnrlCnfgTblNme = ''DynamicListBox''
																AND		GnrlCnfgHdrID <> 0
																)
			Where	TransactionHeader.XHdrID = #Temp_TaxData.SourceID	
			)
	'
	
	exec(@vc_sql)
End


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

IF  OBJECT_ID(N'[dbo].[MTV_TaxRule_MOTValidForFreightRate]') IS NOT NULL
      BEGIN
			EXECUTE	sp_MotivaBuildStatisticsInsertUpdateSQLScripts 'MTV_TaxRule_MOTValidForFreightRate.sql'
			PRINT '<<< ALTERED StoredProcedure MTV_TaxRule_MOTValidForFreightRate >>>'
	  END
	  ELSE
	  BEGIN
			PRINT '<<< FAILED CREATE OR ALTER on StoredProcedure MTV_TaxRule_MOTValidForFreightRate >>>'
	  END