
Update	NexusRouterType
Set		CallBackClass = 'Motiva.RightAngle.Server.Accounting.Entities.SAPInterface.MTVSAPMessageHandler'
Where	RouterName in ('SAPAROutbound','SAPAPOutbound','SAPGLOutbound')