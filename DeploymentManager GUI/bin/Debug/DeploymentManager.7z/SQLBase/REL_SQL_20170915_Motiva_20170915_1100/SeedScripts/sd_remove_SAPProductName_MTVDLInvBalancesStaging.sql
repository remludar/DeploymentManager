
exec SRA_Drop_Column 'MTVDLInvBalancesStaging', 'SAPProductName'
